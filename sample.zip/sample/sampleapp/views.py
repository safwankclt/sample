from django.shortcuts import render,redirect
from .models import Details,Photo

# Create your views here.
def index(request):
    images=Photo.objects.all()
    return render(request,'index.html',{'images':images})

def create(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        obj=Details.objects.create(name=name,email=email,phone=phone)
        obj.save()
        return redirect('/')
    

