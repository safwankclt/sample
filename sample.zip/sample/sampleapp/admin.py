from django.contrib import admin
from .models import Details,Photo

# Register your models here.
admin.site.register(Details)
admin.site.register(Photo)